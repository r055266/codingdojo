<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
	<body>
		<div id="main_content">
			<form action="process.php?important_dojo_message=KB+is+the+best!" class="login" method="post">
				<label for="user_name">User Name:</label>
				<input type="text" name="user_name">
				<label for="email">Email:</label>
				<input type="text" name="email">
				<label for="password">Password:</label>
				<input type="password" name="password">
				<input type="submit" value="submit">
			</form>
		</div>
	</body>
</html>