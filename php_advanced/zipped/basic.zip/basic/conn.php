<?php
$db_host = '127.0.0.1';
$db_user = 'root';
$db_pass = 'Slalom#6';
$db_name = 'lead_gen_business';

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name) or die('Could not connect to database'); 
?>